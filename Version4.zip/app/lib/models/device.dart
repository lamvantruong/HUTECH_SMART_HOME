class Device {
  String id;
  String name;
  String type; // light, ac, fan, door
  bool isOn;
  double value; 
  String roomId;

  Device({
    required this.id,
    required this.name,
    required this.type,
    required this.roomId,
    this.isOn = false,
    this.value = 0.0,
  });
}
