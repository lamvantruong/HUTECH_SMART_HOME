class Room {
  String id;
  String name;
  String iconType;

  Room({
    required this.id,
    required this.name,
    required this.iconType,
  });
}
