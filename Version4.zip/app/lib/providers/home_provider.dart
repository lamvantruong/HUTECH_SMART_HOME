import 'package:flutter/material.dart';
import '../models/device.dart';
import '../models/room.dart';

class HomeProvider with ChangeNotifier {
  final List<Room> _rooms = [
    Room(id: 'r1', name: 'Phòng Khách', iconType: 'living_room'),
    Room(id: 'r2', name: 'Phòng Ngủ', iconType: 'bed_room'),
  ];

  final List<Device> _devices = [
    Device(id: 'd1', name: 'Đèn trần', type: 'light', roomId: 'r1', isOn: false),
    Device(id: 'd2', name: 'Máy lạnh', type: 'ac', roomId: 'r1', isOn: true, value: 24.0),
    Device(id: 'd3', name: 'Quạt đứng', type: 'fan', roomId: 'r2', isOn: false),
  ];

  List<Room> get rooms => _rooms;
  List<Device> get devices => _devices;

  void addRoom(String name, String iconType) {
    _rooms.add(Room(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, iconType: iconType));
    notifyListeners();
  }

  void updateRoom(String id, String newName) {
    var room = _rooms.firstWhere((r) => r.id == id);
    room.name = newName;
    notifyListeners();
  }

  void deleteRoom(String id) {
    _rooms.removeWhere((r) => r.id == id);
    _devices.removeWhere((d) => d.roomId == id); 
    notifyListeners();
  }

  List<Device> getDevicesByRoom(String roomId) {
    return _devices.where((d) => d.roomId == roomId).toList();
  }

  void addDevice(String roomId, String name, String type) {
    _devices.add(Device(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      type: type,
      roomId: roomId,
    ));
    notifyListeners();
  }

  void removeDevice(String deviceId) {
    _devices.removeWhere((d) => d.id == deviceId);
    notifyListeners();
  }

  void toggleDevice(String id) {
    var device = _devices.firstWhere((d) => d.id == id);
    device.isOn = !device.isOn;
    notifyListeners();
  }

  void updateDeviceValue(String id, double val) {
    var device = _devices.firstWhere((d) => d.id == id);
    device.value = val;
    notifyListeners();
  }
}
