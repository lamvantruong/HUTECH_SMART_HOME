import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;
  String _errorMessage = '';

  bool get isAuthenticated => _isAuthenticated;
  String get errorMessage => _errorMessage;

  bool login(String email, String password) {
    // Hardcoded credentials for demonstration
    if (email == 'admin@hutech.edu.vn' && password == '123') {
      _isAuthenticated = true;
      _errorMessage = '';
      notifyListeners();
      return true;
    } else {
      _isAuthenticated = false;
      _errorMessage = 'Email hoặc mật khẩu không đúng.';
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _isAuthenticated = false;
    notifyListeners();
  }
}
