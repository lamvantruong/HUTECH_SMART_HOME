import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  List<AppUser> _users = [];
  AppUser? _currentUser;
  String _errorMessage = '';

  List<AppUser> get users => _users;
  AppUser? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  String get errorMessage => _errorMessage;

  AuthProvider() {
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final usersStr = prefs.getString('users_data');
    if (usersStr != null && usersStr.isNotEmpty) {
      final List decoded = jsonDecode(usersStr);
      _users = decoded.map((e) => AppUser.fromJson(e)).toList();
    } else {
      _users = [
        AppUser(id: 'u1', username: 'admin', password: 'admin', role: 'admin'),
        AppUser(id: 'u2', username: 'user', password: 'user', role: 'user'),
      ];
      _saveUsers();
    }
    notifyListeners();
  }

  Future<void> _saveUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = jsonEncode(_users.map((e) => e.toJson()).toList());
    await prefs.setString('users_data', encoded);
  }

  bool login(String username, String password) {
    try {
      var user = _users.firstWhere((u) => u.username == username && u.password == password);
      _currentUser = user;
      _errorMessage = '';
      notifyListeners();
      return true;
    } catch (e) {
      _currentUser = null;
      _errorMessage = 'Tài khoản hoặc mật khẩu không đúng.';
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  void addUser(String username, String password, String role) {
    if (_currentUser?.role != 'admin') {
      _errorMessage = 'Chỉ quản trị viên mới có quyền thêm tài khoản.';
      notifyListeners();
      return;
    }
    if (_users.any((u) => u.username == username)) {
      _errorMessage = 'Tài khoản đã tồn tại trong hệ thống.';
      notifyListeners();
      return;
    }
    _users.add(AppUser(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      username: username,
      password: password,
      role: role,
    ));
    _errorMessage = '';
    _saveUsers();
    notifyListeners();
  }

  void deleteUser(String id) {
    if (_currentUser?.role != 'admin') {
      _errorMessage = 'Chỉ quản trị viên mới có quyền xóa tài khoản.';
      notifyListeners();
      return;
    }
    if (_currentUser?.id == id) {
      _errorMessage = 'Không thể xóa chính tài khoản đang đăng nhập.';
      notifyListeners();
      return;
    }
    _users.removeWhere((u) => u.id == id);
    _errorMessage = '';
    _saveUsers();
    notifyListeners();
  }
}