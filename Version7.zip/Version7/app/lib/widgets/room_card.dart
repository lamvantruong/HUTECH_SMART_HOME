import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/room.dart';
import '../providers/home_provider.dart';
import '../screens/room_detail_screen.dart';

class RoomCard extends StatelessWidget {
  final Room room;

  const RoomCard({super.key, required this.room});

  void _showEditDialog(BuildContext context) {
    final TextEditingController controller = TextEditingController(text: room.name);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sửa Tên Phòng'),
        content: TextField(controller: controller),
        actions: [
          TextButton(
            onPressed: () {
              Provider.of<HomeProvider>(context, listen: false).deleteRoom(room.id);
              Navigator.pop(ctx);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Xóa Phòng'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          ElevatedButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                Provider.of<HomeProvider>(context, listen: false).updateRoom(room.id, controller.text);
                Navigator.pop(ctx);
              }
            },
            child: const Text('Lưu'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final deviceCount = Provider.of<HomeProvider>(context).getDevicesByRoom(room.id).length;
    
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RoomDetailScreen(room: room))),
      onLongPress: () => _showEditDialog(context),
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                room.iconType == 'living_room' ? Icons.weekend : 
                room.iconType == 'bed_room' ? Icons.bed : Icons.meeting_room,
                size: 48,
                color: Colors.blueAccent,
              ),
              const SizedBox(height: 12),
              Text(room.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              const SizedBox(height: 4),
              Text('$deviceCount thiết bị', style: const TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}