import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../providers/home_provider.dart';

class DeviceCard extends StatelessWidget {
  final Device device;

  const DeviceCard({super.key, required this.device});

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa Thiết Bị'),
        content: Text('Bạn có chắc chắn muốn xóa "${device.name}" không?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          ElevatedButton(
            onPressed: () {
              Provider.of<HomeProvider>(context, listen: false).removeDevice(device.id);
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Xóa'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: () => _confirmDelete(context),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    device.type == 'light' ? Icons.lightbulb :
                    device.type == 'ac' ? Icons.ac_unit :
                    device.type == 'fan' ? Icons.mode_fan_off : Icons.door_front_door,
                    size: 40,
                    color: device.isOn ? Colors.blueAccent : Colors.grey,
                  ),
                  Switch(
                    value: device.isOn,
                    onChanged: (val) {
                      Provider.of<HomeProvider>(context, listen: false).toggleDevice(device.id);
                    },
                  )
                ],
              ),
              Text(device.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              if (device.type == 'ac') ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Nhiệt độ: ', style: TextStyle(color: Colors.grey)),
                    Text('${device.value.toInt()} °C', style: const TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                  ],
                ),
                Slider(
                  value: device.value,
                  min: 16,
                  max: 30,
                  divisions: 14,
                  label: '${device.value.toInt()}',
                  onChanged: device.isOn ? (val) {
                    Provider.of<HomeProvider>(context, listen: false).updateDeviceValue(device.id, val);
                  } : null,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}