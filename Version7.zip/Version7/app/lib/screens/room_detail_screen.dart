import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/room.dart';
import '../providers/home_provider.dart';
import '../widgets/device_card.dart';

class RoomDetailScreen extends StatefulWidget {
  final Room room;

  const RoomDetailScreen({super.key, required this.room});

  @override
  State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  void _showAddDeviceDialog(BuildContext context) {
    final TextEditingController nameController = TextEditingController();
    String selectedType = 'light';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Thêm Thiết Bị'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(hintText: 'Nhập tên thiết bị (VD: Đèn trần)'),
                ),
                const SizedBox(height: 16),
                DropdownButton<String>(
                  value: selectedType,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: 'light', child: Text('Đèn (Light)')),
                    DropdownMenuItem(value: 'fan', child: Text('Quạt (Fan)')),
                    DropdownMenuItem(value: 'ac', child: Text('Máy lạnh (AC)')),
                    DropdownMenuItem(value: 'door', child: Text('Cửa (Door)')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      if (value != null) selectedType = value;
                    });
                  },
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
              ElevatedButton(
                onPressed: () {
                  if (nameController.text.isNotEmpty) {
                    Provider.of<HomeProvider>(context, listen: false)
                        .addDevice(widget.room.id, nameController.text, selectedType);
                    Navigator.pop(ctx);
                  }
                },
                child: const Text('Lưu'),
              )
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<HomeProvider>(context);
    final roomDevices = provider.getDevicesByRoom(widget.room.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.room.name),
      ),
      body: roomDevices.isEmpty
        ? const Center(child: Text('Chưa có thiết bị nào trong phòng này.'))
        : GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 0.85,
            ),
            itemCount: roomDevices.length,
            itemBuilder: (context, index) {
              return DeviceCard(device: roomDevices[index]);
            },
          ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddDeviceDialog(context),
        backgroundColor: Colors.orangeAccent,
        child: const Icon(Icons.add_to_home_screen),
      ),
    );
  }
}