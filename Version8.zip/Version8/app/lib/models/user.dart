class AppUser {
  String id; String username; String password; String role;
  AppUser({required this.id, required this.username, required this.password, required this.role});
  Map<String, dynamic> toJson() => {'id': id, 'username': username, 'password': password, 'role': role};
  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(id: json['id'], username: json['username'], password: json['password'], role: json['role']);
}
