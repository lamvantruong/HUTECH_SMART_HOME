class Device {
  String id; String name; String type; bool isOn; double value; String roomId;
  Device({required this.id, required this.name, required this.type, required this.roomId, this.isOn = false, this.value = 0.0});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type, 'isOn': isOn, 'value': value, 'roomId': roomId};
  factory Device.fromJson(Map<String, dynamic> json) => Device(id: json['id'], name: json['name'], type: json['type'], roomId: json['roomId'], isOn: json['isOn'], value: (json['value'] as num).toDouble());
}
