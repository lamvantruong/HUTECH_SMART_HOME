import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  List<AppUser> _users = [];
  AppUser? _currentUser;
  String _errorMessage = '';

  List<AppUser> get users => _users;
  AppUser? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  String get errorMessage => _errorMessage;

  // Xử lý File IO
  Future<File> get _localFile async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/hutech_users.json');
  }

  // Khởi tạo dữ liệu
  Future<void> initData() async {
    try {
      final file = await _localFile;
      if (await file.exists()) {
        final String contents = await file.readAsString();
        final List<dynamic> jsonList = jsonDecode(contents);
        _users = jsonList.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e))).toList();
      } 
      
      // Nếu file trống hoặc chưa có tài khoản nào, tạo mặc định
      if (_users.isEmpty) {
        _users = [
          AppUser(id: 'u1', username: 'admin', password: 'admin', role: 'admin'),
          AppUser(id: 'u2', username: 'user', password: 'user', role: 'user'),
        ];
        await _saveUsers();
      }
    } catch (e) {
      print("Lỗi đọc File Users JSON: $e");
      // Fallback
      _users = [
        AppUser(id: 'u1', username: 'admin', password: 'admin', role: 'admin'),
        AppUser(id: 'u2', username: 'user', password: 'user', role: 'user'),
      ];
      await _saveUsers();
    }
  }

  Future<void> _saveUsers() async {
    try {
      final file = await _localFile;
      final String jsonString = jsonEncode(_users.map((e) => e.toJson()).toList());
      await file.writeAsString(jsonString);
    } catch (e) {
      print("Lỗi ghi File Users JSON: $e");
    }
  }

  bool login(String username, String password) {
    try {
      _currentUser = _users.firstWhere((u) => u.username == username && u.password == password);
      _errorMessage = ''; notifyListeners(); return true;
    } catch (e) {
      _currentUser = null; _errorMessage = 'Tài khoản hoặc mật khẩu không đúng.';
      notifyListeners(); return false;
    }
  }

  void logout() { _currentUser = null; notifyListeners(); }

  void addUser(String username, String password, String role) {
    if (_users.any((u) => u.username == username)) {
      _errorMessage = 'Tên tài khoản đã tồn tại.'; notifyListeners(); return;
    }
    _users.add(AppUser(id: DateTime.now().millisecondsSinceEpoch.toString(), username: username, password: password, role: role));
    _errorMessage = ''; _saveUsers(); notifyListeners();
  }

  void updateUser(String id, String newUsername, String newPassword, String newRole) {
    try {
      var user = _users.firstWhere((u) => u.id == id);
      if (user.username != newUsername && _users.any((u) => u.username == newUsername)) {
          _errorMessage = 'Tên tài khoản mới đã tồn tại.'; notifyListeners(); return;
      }
      user.username = newUsername; user.password = newPassword; user.role = newRole;
      _errorMessage = ''; _saveUsers(); notifyListeners();
    } catch (e) {
      _errorMessage = 'Lỗi cập nhật tài khoản.'; notifyListeners();
    }
  }

  void deleteUser(String id) {
    if (_currentUser?.id == id) {
      _errorMessage = 'Không thể xóa chính tài khoản đang đăng nhập.'; notifyListeners(); return;
    }
    _users.removeWhere((u) => u.id == id);
    _errorMessage = ''; _saveUsers(); notifyListeners();
  }
}
