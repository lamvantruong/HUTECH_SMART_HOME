import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import '../models/device.dart'; import '../models/room.dart';

class HomeProvider with ChangeNotifier {
  final String esp32IpAddress = "http://192.168.1.100";

  List<Room> _rooms = []; 
  List<Device> _devices = [];
  
  List<Room> get rooms => _rooms; List<Device> get devices => _devices;

  // Xử lý File IO
  Future<File> get _roomsFile async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/hutech_rooms.json');
  }

  Future<File> get _devicesFile async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/hutech_devices.json');
  }

  // Khởi tạo
  Future<void> initData() async {
    try {
      // Đọc File Rooms
      final rFile = await _roomsFile;
      if (await rFile.exists()) {
        final contents = await rFile.readAsString();
        _rooms = (jsonDecode(contents) as List).map((e) => Room.fromJson(Map<String, dynamic>.from(e))).toList();
      }
      if (_rooms.isEmpty) {
        _rooms = [
          Room(id: 'r1', name: 'Phòng Khách', iconType: 'living_room'),
          Room(id: 'r2', name: 'Phòng Ngủ', iconType: 'bed_room')
        ];
      }

      // Đọc File Devices
      final dFile = await _devicesFile;
      if (await dFile.exists()) {
        final contents = await dFile.readAsString();
        _devices = (jsonDecode(contents) as List).map((e) => Device.fromJson(Map<String, dynamic>.from(e))).toList();
      }
      if (_devices.isEmpty) {
        _devices = [
          Device(id: 'd1', name: 'Đèn trần', type: 'light', roomId: 'r1', isOn: false),
          Device(id: 'd2', name: 'Máy lạnh', type: 'ac', roomId: 'r1', isOn: false)
        ];
      }
    } catch (e) {
      print("Lỗi IO đọc file Data: $e");
    }
  }

  Future<void> _saveData() async {
    try {
      final rFile = await _roomsFile;
      await rFile.writeAsString(jsonEncode(_rooms.map((e) => e.toJson()).toList()));

      final dFile = await _devicesFile;
      await dFile.writeAsString(jsonEncode(_devices.map((e) => e.toJson()).toList()));
    } catch (e) {
      print("Lỗi ghi file Data: $e");
    }
  }

  void addRoom(String name, String iconType) { _rooms.add(Room(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, iconType: iconType)); _saveData(); notifyListeners(); }
  void updateRoom(String id, String newName) { _rooms.firstWhere((r) => r.id == id).name = newName; _saveData(); notifyListeners(); }
  void deleteRoom(String id) { _rooms.removeWhere((r) => r.id == id); _devices.removeWhere((d) => d.roomId == id); _saveData(); notifyListeners(); }
  List<Device> getDevicesByRoom(String roomId) => _devices.where((d) => d.roomId == roomId).toList();
  
  void addDevice(String id, String roomId, String name, String type) { 
    _devices.add(Device(id: id, name: name, type: type, roomId: roomId)); 
    _saveData(); 
    notifyListeners(); 
  }
  
  void removeDevice(String deviceId) { _devices.removeWhere((d) => d.id == deviceId); _saveData(); notifyListeners(); }
  
  Future<void> toggleDevice(BuildContext context, String id) async {
    var device = _devices.firstWhere((d) => d.id == id);
    device.isOn = !device.isOn;
    
    // Lưu File và update UI ngay lập tức
    _saveData();
    notifyListeners();

    try {
      int stateParam = device.isOn ? 1 : 0;
      final url = Uri.parse('$esp32IpAddress/control?id=$id&state=$stateParam');
      final response = await http.get(url).timeout(const Duration(seconds: 2));
      
      if (response.statusCode != 200) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi từ ESP32: ${response.statusCode}'), backgroundColor: Colors.red));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Đã gửi lệnh $id tới ESP32!'), backgroundColor: Colors.green, duration: const Duration(seconds: 1)));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Không kết nối được ESP32.'), backgroundColor: Colors.orange));
    }
  }

  void updateDeviceValue(String id, double val) { _devices.firstWhere((d) => d.id == id).value = val; _saveData(); notifyListeners(); }
}
