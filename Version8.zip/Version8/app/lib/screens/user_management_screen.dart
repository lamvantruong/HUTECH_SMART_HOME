import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user.dart'; import '../providers/auth_provider.dart';

class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({super.key});
  @override State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  void _showAddOrEditUserDialog(BuildContext context, {AppUser? userToEdit}) {
    final usernameCtrl = TextEditingController(text: userToEdit?.username ?? '');
    final passCtrl = TextEditingController(text: userToEdit?.password ?? '');
    String selectedRole = userToEdit?.role ?? 'user';
    final isEdit = userToEdit != null;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text(isEdit ? 'Sửa Tài Khoản' : 'Thêm Tài Khoản'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: usernameCtrl, decoration: const InputDecoration(labelText: 'Tên tài khoản')),
                TextField(controller: passCtrl, decoration: const InputDecoration(labelText: 'Mật khẩu')),
                const SizedBox(height: 16),
                DropdownButton<String>(
                  value: selectedRole, isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: 'user', child: Text('Người dùng (User)')),
                    DropdownMenuItem(value: 'admin', child: Text('Quản trị (Admin)')),
                  ],
                  onChanged: (val) => setState(() => selectedRole = val!),
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
              ElevatedButton(
                onPressed: () {
                  if (usernameCtrl.text.isNotEmpty && passCtrl.text.isNotEmpty) {
                    final authProv = Provider.of<AuthProvider>(context, listen: false);
                    if (isEdit) authProv.updateUser(userToEdit.id, usernameCtrl.text.trim(), passCtrl.text, selectedRole);
                    else authProv.addUser(usernameCtrl.text.trim(), passCtrl.text, selectedRole);
                    if (authProv.errorMessage.isNotEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(authProv.errorMessage), backgroundColor: Colors.red));
                    } else { Navigator.pop(ctx); }
                  }
                }, child: const Text('Lưu'),
              )
            ],
          );
        },
      ),
    );
  }

  void _confirmDelete(BuildContext context, String id, String username) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa Tài Khoản'), content: Text('Xác nhận xóa tài khoản $username?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          ElevatedButton(
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).deleteUser(id);
              final err = Provider.of<AuthProvider>(context, listen: false).errorMessage;
              if (err.isNotEmpty) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err), backgroundColor: Colors.red));
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white), child: const Text('Xóa'),
          )
        ],
      ),
    );
  }

  @override Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Quản lý Người Dùng')),
      body: ListView.builder(
        itemCount: authProvider.users.length,
        itemBuilder: (context, index) {
          final user = authProvider.users[index];
          final isCurrentUser = user.id == authProvider.currentUser?.id;
          return ListTile(
            leading: Icon(user.role == 'admin' ? Icons.admin_panel_settings : Icons.person),
            title: Text(user.username), subtitle: Text('Quyền: ${user.role}'),
            trailing: isCurrentUser 
              ? Row(mainAxisSize: MainAxisSize.min, children: [const Text('Bạn', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)), IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () => _showAddOrEditUserDialog(context, userToEdit: user))])
              : Row(mainAxisSize: MainAxisSize.min, children: [IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () => _showAddOrEditUserDialog(context, userToEdit: user)), IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => _confirmDelete(context, user.id, user.username))]),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(onPressed: () => _showAddOrEditUserDialog(context), child: const Icon(Icons.person_add)),
    );
  }
}
