import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/room.dart'; import '../providers/home_provider.dart'; import '../widgets/device_card.dart';

class RoomDetailScreen extends StatefulWidget {
  final Room room; const RoomDetailScreen({super.key, required this.room});
  @override State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  void _showAddDeviceDialog(BuildContext context) {
    final provider = Provider.of<HomeProvider>(context, listen: false);
    
    List<String> allIds = List.generate(10, (index) => 'd${index + 1}');
    List<String> usedIds = provider.devices.map((d) => d.id).toList();
    List<String> availableIds = allIds.where((id) => !usedIds.contains(id)).toList();

    if (availableIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã đạt giới hạn tối đa 10 thiết bị (d1-d10)!'), backgroundColor: Colors.red));
      return;
    }

    final nameCtrl = TextEditingController(); 
    String selectedType = 'light';
    String selectedId = availableIds.first;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Thêm Thiết Bị Mới'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButton<String>(
                  value: selectedId, isExpanded: true,
                  items: availableIds.map((id) => DropdownMenuItem(value: id, child: Text('Cổng kết nối: $id'))).toList(),
                  onChanged: (value) => setState(() => selectedId = value!),
                ),
                const SizedBox(height: 16),
                TextField(controller: nameCtrl, decoration: const InputDecoration(hintText: 'Nhập tên thiết bị (VD: Đèn trần)')),
                const SizedBox(height: 16),
                DropdownButton<String>(
                  value: selectedType, isExpanded: true,
                  items: const [DropdownMenuItem(value: 'light', child: Text('Đèn')), DropdownMenuItem(value: 'fan', child: Text('Quạt')), DropdownMenuItem(value: 'ac', child: Text('Máy lạnh')), DropdownMenuItem(value: 'door', child: Text('Cửa'))],
                  onChanged: (value) => setState(() => selectedType = value!),
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
              ElevatedButton(
                onPressed: () {
                  if (nameCtrl.text.isNotEmpty) {
                    Provider.of<HomeProvider>(context, listen: false).addDevice(selectedId, widget.room.id, nameCtrl.text, selectedType);
                    Navigator.pop(ctx);
                  }
                }, child: const Text('Lưu'),
              )
            ],
          );
        },
      ),
    );
  }

  @override Widget build(BuildContext context) {
    final provider = Provider.of<HomeProvider>(context);
    final roomDevices = provider.getDevicesByRoom(widget.room.id);
    return Scaffold(
      appBar: AppBar(title: Text(widget.room.name)),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            color: Colors.blue.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.router, color: Colors.blue.shade700, size: 20),
                const SizedBox(width: 8),
                Text('Đang kết nối ESP32: ${provider.esp32IpAddress}', 
                  style: TextStyle(color: Colors.blue.shade700, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Expanded(
            child: roomDevices.isEmpty 
              ? const Center(child: Text('Chưa có thiết bị nào.')) 
              : GridView.builder(
                  padding: const EdgeInsets.all(16), 
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 16, mainAxisSpacing: 16, childAspectRatio: 0.85), 
                  itemCount: roomDevices.length, 
                  itemBuilder: (context, index) => DeviceCard(device: roomDevices[index])
                ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: () => _showAddDeviceDialog(context), backgroundColor: Colors.orangeAccent, child: const Icon(Icons.add_to_home_screen)),
    );
  }
}
