#include <WiFi.h>
#include <WebServer.h>

// ==========================================
// 1. CẤU HÌNH WI-FI 
// ==========================================
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

IPAddress local_IP(192, 168, 1, 100);      
IPAddress gateway(192, 168, 1, 1);         
IPAddress subnet(255, 255, 255, 0);        
IPAddress primaryDNS(8, 8, 8, 8);          
IPAddress secondaryDNS(8, 8, 4, 4);

WebServer server(80);

// ==========================================
// 2. KHAI BÁO CẤU TRÚC ÁNH XẠ PIN (STRUCT)
// CẢNH BÁO KỸ THUẬT: Chân D34 và D35 trên ESP32 là các chân Input-Only 
// (không thể xuất mức Logic HIGH/LOW). Để an toàn, hãy cắm Relay vào các chân khác.
// Tuy nhiên, mã nguồn vẫn ánh xạ đúng yêu cầu của bạn.
// ==========================================
struct DevicePin {
  String id;
  int pin;
};

// Mảng 10 thiết bị từ d1 đến d10
DevicePin devices[10] = {
  {"d1", 13},
  {"d2", 12},
  {"d3", 14},
  {"d4", 27},
  {"d5", 26},
  {"d6", 25},
  {"d7", 33},
  {"d8", 32},
  {"d9", 15}, 
  {"d10", 2}
};

// ==========================================
// 3. HÀM XỬ LÝ API TỪ FLUTTER
// ==========================================
void handleControl() {
  if (server.hasArg("id") && server.hasArg("state")) {
    String deviceId = server.arg("id");
    int state = server.arg("state").toInt();
    int pinState = (state == 1) ? HIGH : LOW; 
    String stateStr = (state == 1) ? "BẬT (ON)" : "TẮT (OFF)";

    Serial.println("\n========== NHẬN LỆNH TỪ APP ==========");
    Serial.print("ID Thiết bị yêu cầu: ");
    Serial.println(deviceId);

    bool isFound = false;

    // Quét mảng để tìm đúng ID và kích hoạt chân GPIO tương ứng
    for (int i = 0; i < 10; i++) {
      if (devices[i].id == deviceId) {
        digitalWrite(devices[i].pin, pinState);
        Serial.println("Trạng thái: " + deviceId + " (Chân D" + String(devices[i].pin) + ") -> " + stateStr);
        isFound = true;
        break; // Dừng vòng lặp khi đã tìm thấy
      }
    }

    if (!isFound) {
      Serial.println("[CẢNH BÁO] Không tìm thấy ID Thiết bị trong hệ thống ESP32!");
    }
    
    Serial.println("======================================");
    server.send(200, "application/json", "{\"status\":\"success\"}");
  } else {
    Serial.println("\n[LỖI] Thiếu tham số ID hoặc State!");
    server.send(400, "application/json", "{\"status\":\"error\", \"message\":\"Thiếu tham số\"}");
  }
}

// ==========================================
// 4. HÀM KHỞI TẠO
// ==========================================
void setup() {
  Serial.begin(115200);
  
  // Lặp qua mảng thiết bị để pinMode Output và tắt mặc định
  for (int i = 0; i < 10; i++) {
    pinMode(devices[i].pin, OUTPUT);
    digitalWrite(devices[i].pin, LOW);
  }

  Serial.println();
  if (!WiFi.config(local_IP, gateway, subnet, primaryDNS, secondaryDNS)) {
    Serial.println("Cảnh báo: Cấu hình IP Tĩnh thất bại!");
  }

  Serial.print("Đang kết nối Wi-Fi: ");
  Serial.println(ssid);
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\n[KẾT NỐI THÀNH CÔNG]");
  Serial.print("ĐỊA CHỈ IP ESP32 LÀ: ");
  Serial.println(WiFi.localIP()); 

  server.on("/control", HTTP_GET, handleControl);
  server.begin();
  Serial.println("HTTP Server đang lắng nghe lệnh điều khiển...");
}

void loop() {
  server.handleClient();
}
