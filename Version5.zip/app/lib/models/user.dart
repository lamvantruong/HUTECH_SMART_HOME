class AppUser {
  String id;
  String email;
  String password;
  String role; // 'admin' or 'user'

  AppUser({
    required this.id,
    required this.email,
    required this.password,
    required this.role,
  });
}
