import 'package:flutter/material.dart';
import '../models/device.dart'; import '../models/room.dart';
class HomeProvider with ChangeNotifier {
  final List<Room> _rooms = [Room(id: 'r1', name: 'Phòng Khách', iconType: 'living_room')];
  final List<Device> _devices = [Device(id: 'd1', name: 'Đèn trần', type: 'light', roomId: 'r1', isOn: false)];
  List<Room> get rooms => _rooms; List<Device> get devices => _devices;
  void addRoom(String name, String iconType) { _rooms.add(Room(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, iconType: iconType)); notifyListeners(); }
  void updateRoom(String id, String newName) { var r = _rooms.firstWhere((r) => r.id == id); r.name = newName; notifyListeners(); }
  void deleteRoom(String id) { _rooms.removeWhere((r) => r.id == id); _devices.removeWhere((d) => d.roomId == id); notifyListeners(); }
  List<Device> getDevicesByRoom(String roomId) { return _devices.where((d) => d.roomId == roomId).toList(); }
  void addDevice(String roomId, String name, String type) { _devices.add(Device(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, type: type, roomId: roomId)); notifyListeners(); }
  void removeDevice(String deviceId) { _devices.removeWhere((d) => d.id == deviceId); notifyListeners(); }
  void toggleDevice(String id) { var d = _devices.firstWhere((d) => d.id == id); d.isOn = !d.isOn; notifyListeners(); }
  void updateDeviceValue(String id, double val) { var d = _devices.firstWhere((d) => d.id == id); d.value = val; notifyListeners(); }
}