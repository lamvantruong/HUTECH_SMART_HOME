import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({super.key});

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  void _showAddUserDialog(BuildContext context) {
    final TextEditingController emailCtrl = TextEditingController();
    final TextEditingController passCtrl = TextEditingController();
    String selectedRole = 'user';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Thêm Tài Khoản'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email')),
                TextField(controller: passCtrl, decoration: const InputDecoration(labelText: 'Mật khẩu')),
                const SizedBox(height: 16),
                DropdownButton<String>(
                  value: selectedRole,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: 'user', child: Text('Người dùng (User)')),
                    DropdownMenuItem(value: 'admin', child: Text('Quản trị (Admin)')),
                  ],
                  onChanged: (val) => setState(() => selectedRole = val!),
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
              ElevatedButton(
                onPressed: () {
                  if (emailCtrl.text.isNotEmpty && passCtrl.text.isNotEmpty) {
                    Provider.of<AuthProvider>(context, listen: false)
                        .addUser(emailCtrl.text, passCtrl.text, selectedRole);
                    final err = Provider.of<AuthProvider>(context, listen: false).errorMessage;
                    if (err.isNotEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err), backgroundColor: Colors.red));
                    } else {
                      Navigator.pop(ctx);
                    }
                  }
                },
                child: const Text('Lưu'),
              )
            ],
          );
        },
      ),
    );
  }

  void _confirmDelete(BuildContext context, String id, String email) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa Tài Khoản'),
        content: Text('Xác nhận xóa tài khoản $email?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          ElevatedButton(
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).deleteUser(id);
              final err = Provider.of<AuthProvider>(context, listen: false).errorMessage;
              if (err.isNotEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err), backgroundColor: Colors.red));
              }
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Xóa'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final users = authProvider.users;

    return Scaffold(
      appBar: AppBar(title: const Text('Quản lý Người Dùng')),
      body: ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, index) {
          final user = users[index];
          final isCurrentUser = user.id == authProvider.currentUser?.id;
          return ListTile(
            leading: Icon(user.role == 'admin' ? Icons.admin_panel_settings : Icons.person),
            title: Text(user.email),
            subtitle: Text('Quyền: ${user.role}'),
            trailing: isCurrentUser 
              ? const Text('Bạn', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))
              : IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _confirmDelete(context, user.id, user.email),
                ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddUserDialog(context),
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
