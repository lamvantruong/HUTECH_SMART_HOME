class Room {
  String id;
  String name;
  String iconType;

  Room({required this.id, required this.name, required this.iconType});

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'iconType': iconType,
  };

  factory Room.fromJson(Map<String, dynamic> json) => Room(
    id: json['id'],
    name: json['name'],
    iconType: json['iconType'],
  );
}
