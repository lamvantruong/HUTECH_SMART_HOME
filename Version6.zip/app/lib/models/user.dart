class AppUser {
  String id;
  String email;
  String password;
  String role;

  AppUser({
    required this.id,
    required this.email,
    required this.password,
    required this.role,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'email': email,
    'password': password,
    'role': role,
  };

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
    id: json['id'],
    email: json['email'],
    password: json['password'],
    role: json['role'],
  );
}
