import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/device.dart';
import '../models/room.dart';

class HomeProvider with ChangeNotifier {
  List<Room> _rooms = [];
  List<Device> _devices = [];

  List<Room> get rooms => _rooms;
  List<Device> get devices => _devices;

  HomeProvider() {
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    
    final roomsStr = prefs.getString('rooms_data');
    if (roomsStr != null && roomsStr.isNotEmpty) {
      final List decodedRooms = jsonDecode(roomsStr);
      _rooms = decodedRooms.map((e) => Room.fromJson(e)).toList();
    } else {
      _rooms = [
        Room(id: 'r1', name: 'Phòng Khách', iconType: 'living_room'),
        Room(id: 'r2', name: 'Phòng Ngủ', iconType: 'bed_room'),
      ];
    }

    final devicesStr = prefs.getString('devices_data');
    if (devicesStr != null && devicesStr.isNotEmpty) {
      final List decodedDevices = jsonDecode(devicesStr);
      _devices = decodedDevices.map((e) => Device.fromJson(e)).toList();
    } else {
      _devices = [
        Device(id: 'd1', name: 'Đèn trần', type: 'light', roomId: 'r1', isOn: false),
        Device(id: 'd2', name: 'Máy lạnh', type: 'ac', roomId: 'r1', isOn: true, value: 24.0),
        Device(id: 'd3', name: 'Quạt đứng', type: 'fan', roomId: 'r2', isOn: false),
      ];
    }
    notifyListeners();
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedRooms = jsonEncode(_rooms.map((e) => e.toJson()).toList());
    final String encodedDevices = jsonEncode(_devices.map((e) => e.toJson()).toList());
    await prefs.setString('rooms_data', encodedRooms);
    await prefs.setString('devices_data', encodedDevices);
  }

  void addRoom(String name, String iconType) {
    _rooms.add(Room(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, iconType: iconType));
    _saveData();
    notifyListeners();
  }

  void updateRoom(String id, String newName) {
    var room = _rooms.firstWhere((r) => r.id == id);
    room.name = newName;
    _saveData();
    notifyListeners();
  }

  void deleteRoom(String id) {
    _rooms.removeWhere((r) => r.id == id);
    _devices.removeWhere((d) => d.roomId == id); 
    _saveData();
    notifyListeners();
  }

  List<Device> getDevicesByRoom(String roomId) {
    return _devices.where((d) => d.roomId == roomId).toList();
  }

  void addDevice(String roomId, String name, String type) {
    _devices.add(Device(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      type: type,
      roomId: roomId,
    ));
    _saveData();
    notifyListeners();
  }

  void removeDevice(String deviceId) {
    _devices.removeWhere((d) => d.id == deviceId);
    _saveData();
    notifyListeners();
  }

  void toggleDevice(String id) {
    var device = _devices.firstWhere((d) => d.id == id);
    device.isOn = !device.isOn;
    _saveData();
    notifyListeners();
  }

  void updateDeviceValue(String id, double val) {
    var device = _devices.firstWhere((d) => d.id == id);
    device.value = val;
    _saveData();
    notifyListeners();
  }
}
