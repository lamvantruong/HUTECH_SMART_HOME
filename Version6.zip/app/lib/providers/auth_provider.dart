import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  List<AppUser> _users = [];
  AppUser? _currentUser;
  String _errorMessage = '';

  List<AppUser> get users => _users;
  AppUser? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  String get errorMessage => _errorMessage;

  AuthProvider() {
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final usersStr = prefs.getString('users_data');
    if (usersStr != null && usersStr.isNotEmpty) {
      final List decoded = jsonDecode(usersStr);
      _users = decoded.map((e) => AppUser.fromJson(e)).toList();
    } else {
      _users = [
        AppUser(id: 'u1', email: 'admin@hutech.edu.vn', password: '123', role: 'admin'),
        AppUser(id: 'u2', email: 'user@hutech.edu.vn', password: '123', role: 'user'),
      ];
      _saveUsers();
    }
    notifyListeners();
  }

  Future<void> _saveUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = jsonEncode(_users.map((e) => e.toJson()).toList());
    await prefs.setString('users_data', encoded);
  }

  bool login(String email, String password) {
    try {
      var user = _users.firstWhere((u) => u.email == email && u.password == password);
      _currentUser = user;
      _errorMessage = '';
      notifyListeners();
      return true;
    } catch (e) {
      _currentUser = null;
      _errorMessage = 'Email hoặc mật khẩu không đúng.';
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  void addUser(String email, String password, String role) {
    if (_users.any((u) => u.email == email)) {
      _errorMessage = 'Email đã tồn tại trong hệ thống.';
      notifyListeners();
      return;
    }
    _users.add(AppUser(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      email: email,
      password: password,
      role: role,
    ));
    _errorMessage = '';
    _saveUsers();
    notifyListeners();
  }

  void deleteUser(String id) {
    if (_currentUser?.id == id) {
      _errorMessage = 'Không thể xóa chính tài khoản đang đăng nhập.';
      notifyListeners();
      return;
    }
    _users.removeWhere((u) => u.id == id);
    _errorMessage = '';
    _saveUsers();
    notifyListeners();
  }
}
